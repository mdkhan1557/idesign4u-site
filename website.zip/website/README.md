# iDesign4U — Production Website

## 📁 Project Structure

```
/website
  index.html          → Home page
  services.html       → Services page
  portfolio.html      → Portfolio + Project Modals
  pricing.html        → Pricing + FAQ
  about.html          → About Us + Team
  contact.html        → Contact Form
  /css
    style.css         → All styles (shared)
  /js
    script.js         → All JavaScript (shared)
  /images             → Add your images here
  README.md           → This file
```

## ✅ Features

- ✔ Multi-page website (6 pages)
- ✔ All navigation links work correctly
- ✔ Portfolio tiles open detailed project modals
- ✔ Pricing toggle (one-time vs monthly)
- ✔ Working contact form with validation
- ✔ FAQ accordion
- ✔ Custom cursor + spark trail
- ✔ 3D tile tilt on hover
- ✔ Scroll reveal animations
- ✔ Count-up stats
- ✔ Infinite marquee
- ✔ Scroll-to-top button
- ✔ Mobile responsive (hamburger menu)
- ✔ Active nav state per page
- ✔ Portfolio filter by category
- ✔ URL param plan pre-selection on contact page

## 🚀 Deployment

### Hostinger
1. Log in → File Manager → public_html
2. Upload all files maintaining the folder structure
3. Visit your domain — done!

### Netlify
1. Drag the entire `/website` folder onto netlify.com/drop
2. Netlify auto-deploys — get a live URL instantly
3. Connect your custom domain in Settings

### Vercel
1. Install Vercel CLI: `npm i -g vercel`
2. `cd website && vercel`
3. Follow prompts — live in 30 seconds

### GitHub Pages
1. Push to a GitHub repo
2. Settings → Pages → Deploy from branch (main/root)
3. Live at `https://yourusername.github.io/repo-name`

## 📝 Customisation

- **Colors**: Edit CSS variables in `css/style.css` (`:root` block)
- **Content**: Edit text directly in each HTML file
- **Logo**: Replace "iDesign4U" text or add `<img>` tag
- **Contact form**: Connect to Formspree/EmailJS by updating `js/script.js` form handler
- **WhatsApp**: Update phone number in `contact.html` WhatsApp link
- **Images**: Add to `/images` folder and reference in HTML

## 📦 Dependencies

- Google Fonts (Syne + DM Sans) — loaded via CDN
- Pure HTML/CSS/JS — no frameworks, no build step required
